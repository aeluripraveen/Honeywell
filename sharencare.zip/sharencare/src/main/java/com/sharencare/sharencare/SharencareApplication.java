package com.sharencare.sharencare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharencareApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharencareApplication.class, args);
	}

}
