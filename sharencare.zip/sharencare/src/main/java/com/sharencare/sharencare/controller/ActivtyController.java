package com.sharencare.sharencare.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sharencare.sharencare.model.Activity;


@RestController
@RequestMapping("/")
public class ActivtyController {
	
	List<Activity> list = new ArrayList<>();
	
	/**
	 * 
	 */
	public ActivtyController() {
		
		list.add(new Activity(1,"Dance","Hyderabad","HoneyWell dance competation"));
		list.add(new Activity(2,"Music","Hyderabad","State level Music event"));
		list.add(new Activity(3,"Sport","Hyderabad","IPL League"));
		list.add(new Activity(4,"Education","Bangalore","Java Training"));
		list.add(new Activity(5,"Music","Bangalore","National Music event"));
		list.add(new Activity(6,"Sport","Bangalore","Kabaddi"));
	}

	@GetMapping("/activities")
	public List<Activity> getAllActivities() {
		
		return list;
	}
	
	@PostMapping("/activities")
	public void createActivity(@Valid @RequestBody Activity product) {
		
		list.add(product);
	}
	@GetMapping("/activities/{Category}")
	public Activity getActivityByCategory(@PathVariable(value = "Category") String category ) {
		return  list.stream().
				filter(a->category.equals(a.getCategory())).findAny().orElse(null);
	}
	@PutMapping("/activities/{id}")
	public ResponseEntity<Activity> updateProduct(@PathVariable(value = "id") int id,
			@Valid @RequestBody Activity activity) {
		Activity activity1 = list.stream().
				filter(a->id==(a.getId())).findAny().orElse(null);
		if (activity1 == null) {
			return ResponseEntity.notFound().build();
		}
		
		activity1.setCategory(activity.getCategory());
		activity1.setContent(activity.getContent());
		return ResponseEntity.ok().body(activity1);
	}

}
